var express = require("express");
var mongoose = require("mongoose");
var data = require("./views/data.json");
var fs = require("fs");
//--------------------------------
// module configuration
var app = express();
//--------------------------------
// middleware configuration
app.use(express.json());
app.use(express.urlencoded({extended:true}));
//--------------------------------
// db configurations
var tasklist = data;
var Schema = mongoose.Schema;
var ObjectId = Schema.ObjectId;
var url = "mongodb+srv://ashrutuplondhe:Z2MT2YEMkaGEUnpJ@ashrudatabase.34lpnbo.mongodb.net/taskmgmtdb?retryWrites=true&w=majority";

var tasks = mongoose.model("tasks", Schema({
    id : ObjectId,
    title : String,
    description : String,
    status : String,
    }));
   
mongoose.connect(url)
.then( res => console.log("DB connected"))
.catch( err => console.log("Error ", err));

//////////////////////////////////////////////////////

    app.get("/", function(req, res){
        res.render("home.pug")
    })

/////////////////////////////////////////////////////
    
    app.get("/Details", function(req, res){
        tasks.find()
            .then(dbres => {
                res.render("Details.pug", {
                    tasklist : dbres
            });    
                 })
                 .catch( error => console.log("Error ", error))
             } )

//////////////////////////////////////////////////////////
   
    app.get("/AddTodo", function(req, res){
        res.render("AddTodo.pug")
    })

    app.post("/AddTodo", function(req, res){
        var task = new tasks({
            description : req.body.description,
            status : req.body.status
            });
     
        task.save()
        .then(function(dbres){
            res.redirect("/Details");
            res.send("added");//console.log("user created", dbres.firstname, " was )
        } )
        .catch(function(err){
            if(err){
                res.render("home.pug",{
                    //error : "email id already exists"
                })
            }else{
                res.render("Details.pug",{
                    error : "something went wrong please try later"
                })
            }
        });
     
    });
    
///////////////////////////////////////////////////////////////
app.get("/search",function(req,res){
    res.render("search.pug");
})
app.post("/search", function(req, res){
    tasks.findOne({ id : req.body.ObjectId })
    .then(function(dbres){
        if(dbres.ObjectId == req.body.ObjectId){
           // console.log("Record found");        
            res.redirect("/Show");
            }else{
                res.render("/",{
                    error : "invalid id"
                })
            }
        })
    .catch(function(err){
        res.render("/",{
            error : "invalid id"
        })
    })
})

///////////////////////////////

// app.get("/Show",function(req,res){
//     res.render("Show.pug");
// });
/////////////////////////////////////////
app.get("/delete",function(req,res){
    res.render("delete.pug");
})
// app.post("/delete/:id", function(req, res){
//     tasks.findByIdAndDelete({ _id : req.params.id })
//     .then(function(dbRes){
//         res.status(200).send({"message" :" deleted" })
//     })
//     .catch(function(err){
//         console.log("Error ", err);
//     })
// })

 app.post("/delete",function(req,res){
 tasks.findByIdAndDelete({ _id : req.body.id })
    .then(function(dbRes){
        res.status(200).send({"message" :" deleted" })
    })
    .catch(function(err){
        console.log("Error ", err);
    })
})

/////////////////////////////////////////////////////////////

// update

app.get("/update", function(req, res){
    res.render("update.pug")
})
// app.post("/update/:id", function(req, res){
//     tasks.findById({ _id : req.params.id })
//     .then(
//         function(res){
//             res.description = req.body.description;
//             res.status = req.body.status;
//             
//res.save().then(function(updatedRes){
//                 // console.log(updatedRes.usertitle, "User was updated")
//                 res.send({"message":" updated"})
//             }).catch(function(updateError){
//                 console.log("Error ", updateError);
//             })
//         }
//     ).catch(
//         function(err){
//             console.log("Error ", err)
//         }
//     )
// }); 

app.post("/update", function(req, res){
    tasks.findById({ _id : req.body.id })
    .then(function(res){
            res.description = req.body.description;
            res.status = req.body.status;
            //res.usercity = req.body.usercity;
 
            res.save().then(function(updatedRes){
                 console.log(updatedRes.description, " was updated ");
            //res.send({"message":" updated"});
            })
        }
    ).catch(
        function(err){
            console.log("Error ", err);
        }
    )
}); 


// web server configurations

app.listen(2525,"localhost",function(error){
    if(error){
        console.log("Error ", error);
    }else{
        console.log("Server is now live on localhost:2525");
    }
})