import axios from "axios";
import { useEffect, useState } from "react";
import Select from 'react-select';
//import sort from "./components/sort";


let App = ()=> {
    let [tasks, setTasks] = useState([]);
    let [show, toggleShow] = useState(true);
    let [task, setTask] = useState({ title : "", description : "", status : "" });
    let [etask, setEditTask] = useState({ title : "", description : "", status : "" });
   // let [sort, setSortData] = useState([]);
    
    useEffect(()=>{
        refresh();
    },[]);

    let refresh = ()=>{
        axios.get("http://localhost:5050/data")
        .then(res => setTasks(res.data))
        .catch(error => console.log("Error ", error ));
    }
    let taskHandler = (evt)=>{
        setTask({...task, [evt.target.id] : evt.target.value });
    };
    let storeEditInfoHandler = (evt)=>{
        setEditTask({...etask, [evt.target.id] : evt.target.value });
    };


const [selectedOption, setSelectedOption] = useState([]);
    const options = [
        { value: 'ToDo', label: 'ToDo' },
        { value: 'Doing', label: 'Doing' },
        { value: 'Done', label: 'Done' }
             ];
     const handleChange = (selectedOption) => {
        setSelectedOption(selectedOption);
        task.status= selectedOption.value;
       
        etask.status=selectedOption.value;
        //refresh();
        console.log(selectedOption.value);
       
              };



    let addTask = ()=>{
        axios.post("http://localhost:5050/data", task )
        .then(res => {
            console.log( res.data.message );
            console.log(selectedOption.value);
             refresh();
            
            setTask({ title : "", description : "", status : "" })
            

        })
        .catch(error => console.log("Error ", error.error ));
    }

    let editTaskHandler = (tid)=>{
        // alert("are you sure to edit this user's info "+ uid );
        axios.get("http://localhost:5050/update/"+tid)
        .then(res => {
            setEditTask(res.data)
            toggleShow(false)
        })
        .catch(err => console.log(err.error))
    }

    let updateSelectedTaskInfo = (tid)=> {
        axios.post("http://localhost:5050/update/"+tid, etask)
        .then(res => {
            console.log(res.data.message);
            refresh();
            toggleShow(true)
        })
        .catch(err => console.log(err))
    }
    let deleteHandler = (tid)=>{
        axios.delete("http://localhost:5050/delete/"+tid)
        .then( res => { 
            console.log( res.data.message );
            refresh();
        })
        .catch(err => {
            console.log(err)
        })
    }


  const [selectedOptionew, setSelectedOptionew] = useState(null);

 let handleChangeew = (option) => {
        setSelectedOptionew(option);
        console.log(`Option selected:`, option);
        if (option.value === "Doing") {
        console.log(tasks.filter(task => task.status === "Doing"));}
        else if (option.value === "Done"){
            console.log(tasks.filter(task => task.status === "Done"));}
        else //(option.value === "ToDo") 
            console.log(tasks.filter(task => task.status === "ToDo"));
              };
    
   
    
    ///////////////////////////////////////
    return <div className="container" >
                <h1>Task Management App</h1>
                                
               { tasks.length > 0 && <div>
                    <h1>Task Card</h1>
                    <table className="table">
                        <thead>
                            <tr>
                                <th>Title</th>
                                <th>Description</th>
                                <th>Status</th>
                                <th>  <Select options={options} value={selectedOptionew} onChange ={handleChangeew}  id="sort" >
                                     </Select></th>
                                </tr>
                        </thead>
                        <tbody >
                            {
                                    tasks.map( (hero, idx) => {
                                    return <tr key={ idx }>
                                                <td>{ hero.title }</td>
                                                <td>{ hero.description }</td>
                                                <td>{hero.status}</td>
                                                <td>
                                                    <button onClick={ ()=> editTaskHandler(hero._id) } className="btn btn-warning">Edit</button>
                                                </td>
                                                <td>
                                                    <button onClick={ ()=> deleteHandler(hero._id)} className="btn btn-danger">Delete</button>
                                                </td>
                                                <td>
                                               
                                                </td>
                                            </tr>
                                })
                            }
                        </tbody>
                    </table>
                </div>}

<hr/>


                { show && <div>
                    <h1>Create A New Task</h1>
                <div className="mb-3">
                    <label htmlFor="title" className="form-label">Task Title</label>
                    <input  onChange={(evt)=> taskHandler(evt)} value={task.title} className="form-control" id="title"/>
                </div>
                <div className="mb-3">
                    <label htmlFor="description" className="form-label">Task Description</label>
                    <input onChange={(evt)=> taskHandler(evt)} value={task.description} className="form-control" id="description"/>
                </div>
                <div className="mb-3" id="statusdiv">
                    <label htmlFor="status" className="form-label"> Task Status</label>
                    <Select options={options} value={selectedOption} onChange={handleChange} id="status"></Select>
                </div>
                
                <button onClick={ addTask } type="submit" className="btn btn-primary">Add New Task</button>
                
                </div>}
                { !show && <div>
                    <hr />

                <h1>Edit The Selected Task</h1>
                <div className="mb-3">
                    <label htmlFor="title" className="form-label">Edit Task Title</label>
                    <input onChange={(evt)=> storeEditInfoHandler(evt)} value={etask.title} className="form-control" id="title"/>
                </div>
                <div className="mb-3">
                    <label htmlFor="description" className="form-label">Edit Task Description</label>
                    <input onChange={(evt)=> storeEditInfoHandler(evt)} value={etask.description} className="form-control" id="description"/>
                </div>
                <div className="mb-3">
                    <label htmlFor="status" className="form-label">Edit Task Status</label>
                    <Select options={options} value={selectedOption} onChange={handleChange} id="status"></Select>
                 </div>
                <button type="submit" onClick={ ()=> updateSelectedTaskInfo(etask._id) } className="btn btn-primary">Edit Task Info </button>
                </div>}
               </div>
}

export default App;