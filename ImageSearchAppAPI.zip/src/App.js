import { useState } from 'react';
import './App.css';
import { LoadImages,SearchImages } from './components/api';
import Image from './components/image';

let App = () => {
 const [query,setQuery]=useState();
 const [searchQ,setSearch]=useState();
 
 const data = LoadImages();

 const search = ()=>{

 setSearch(query);
               }
const searchData= SearchImages(searchQ);
console.log(searchData);
 
  return (
    <div>
      <center className='input'> <input type='text' onChange={(event)=>setQuery(event.target.value)}/>
            <button className='input'  onClick={search}>Search</button>
      </center>
      {document.getElementById("1")}
      <div className='contain'>  
        
          {searchQ ? searchData.map((img,index) => (
          <div key={index}><a href={img.urls.full}><Image src={img.urls.small}  /></a></div>
                ))  : data.map((img,index) => (
          <div key={index}> <Image src={img.urls.small} /></div>
      )) 
      
      }
    </div>
    </div>

  );
}

export default App;
