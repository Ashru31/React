import React from "react";
 const imgload = ()=>{
  console.log("loading the images");
  document.body.style.backgroundColor="#ffe6e6";
 
 // document.getElementById("root").innerHTML="loading the images"; 
 // above line also executes but takes time to load pictures. So I have used console.log method to test the on load function 
 
}

 const imgerror = (event) => {
  //event.currentTarget.src = "https://images.unsplash.com/photo-1500835556837-99ac94a94552?crop=entropy&cs=srgb&fm=jpg&ixid=M3w0NzMyNDh8MHwxfHNlYXJjaHw3fHxwbGFuZXxlbnwwfHx8fDE2ODk2MTczNzV8MA&ixlib=rb-4.0.3&q=85";
  event.currentTarget.src="https://kennyleeholmes.com/wp-content/uploads/2017/09/no-image-available.png"
  
}

class Image extends React.Component{
    render(){
        return (
  //<img src={this.props.src} alt="decorative images" onLoad={imgload()} onError={(e)=>{e.target.src="https://images.unsplash.com/photo-1500835556837-99ac94a94552?crop=entropy&cs=srgb&fm=jpg&ixid=M3w0NzMyNDh8MHwxfHNlYXJjaHw3fHxwbGFuZXxlbnwwfHx8fDE2ODk2MTczNzV8MA&ixlib=rb-4.0.3&q=85"}}/>
  <img src={this.props.src} alt="decorative images" onLoad={imgload()} onError={imgerror}/>
       
  )
    }
}
export default Image;

