//import React from 'react';

const Loader = () => {
  return (
   // console.log("Loading"));
    <div className="loader" id="1">
        Loading....        
    </div>
  );
}

export default Loader;