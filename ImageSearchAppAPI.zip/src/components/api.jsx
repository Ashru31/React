import axios from "axios";
import { useEffect,useState } from "react";


const count = 1;

let LoadImages = () => {
const [state,setState] = useState([])


useEffect(() => {
axios
     .get("https://api.unsplash.com/photos?client_id=0JkAHVSI8YWAVoGu7uBAaARpl6IwcYyoTFu3Ac6eUZs")
     .then((data) => {
        setState(data.data);
     })
    },[count])
return state;
}


let SearchImages = (query) => {
    const [state,setState] = useState([])
    const [hasError, setError] = useState(false);
    
    
    useEffect(() => {
      try{   
      axios
         .get("https://api.unsplash.com/search/photos?query="+query+"&client_id=0JkAHVSI8YWAVoGu7uBAaARpl6IwcYyoTFu3Ac6eUZs")
         .then((data) => {
            setState(data.data.results);
               })
     
      }catch(error) {
            console.error(error)
            setError(true);
         }
         },[query])
         if (hasError) {
            return <div>Sorry, error detected!</div>
                       }
        
         return state;
      } 
      
    export {LoadImages,SearchImages};

    